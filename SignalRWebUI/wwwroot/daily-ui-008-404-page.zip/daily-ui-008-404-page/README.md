# Daily UI #008: 404 Page

A Pen created on CodePen.

Original URL: [https://codepen.io/supah/pen/RrzREx](https://codepen.io/supah/pen/RrzREx).

https://dailyui.co/ #008